/*
 * stdio.h
 *
 *  Created on: Sep 17, 2018
 *      Author: maanu
 */

#ifndef LIB_STDIO_H_
#define LIB_STDIO_H_

uint32_t putstr(const char* s);

#endif /* LIB_STDIO_H_ */
